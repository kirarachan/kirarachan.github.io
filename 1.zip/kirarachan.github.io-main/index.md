# Home

欢迎来到部落格，这里有无论 $f(x)=y$ 如何都不会消失的奇思妙想

$$f(x)=y$$

有趣的帖子在等待着大家的到来。

## Latest posts

*暂时还没有帖子呢，过几天再来看看吧~*

## More information

- 前往 [Index]() 查找所有帖子。

- 前往 [About]() 了解这个博客。
